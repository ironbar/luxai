VAL_FILES = [
    'North_To_Alaska_-_All_The_Same',
    'Alexander_Ross_-_Velvet_Curtain',
    'ANiMAL_-_Easy_Tiger',
    'Meaxic_-_Take_A_Step',
    'Music_Delta_-_Disco',
]
