# Evaluate

Run

> python -m cunet.evaluate.results        # check cunet/evaluate/config.py for the configuration

TODO: explain the how the different configurations
